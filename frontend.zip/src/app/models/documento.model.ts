export interface Documento {
  U_IdDocumento:   number;
  U_CodPerfil:     number;
  U_TipDoc:        string;
  U_EXENTOpercent: number;
  U_IdTipoDoc:     number;
  U_TipoCalc:      string;  // 'G' | 'N'
  U_IVApercent:    number;
  U_IVAcuenta:     string;
  U_ITpercent:     number;
  U_ITcuenta:      string;
  U_IUEpercent:    number;
  U_IUEcuenta:     string;
  U_RCIVApercent:  number;
  U_RCIVAcuenta:   string;
  U_CTAEXENTO:     string;
  U_TASA:          number;
  U_ICE:           number;
  U_NombrePerfil?: string;
}

export interface CreateDocumentoPayload {
  codPerfil:     number;
  tipDoc:        string;
  idTipoDoc:     number;
  tipoCalc:      string;
  ivaPercent:    number;
  ivaCuenta:     string;
  itPercent:     number;
  itCuenta:      string;
  iuePercent:    number;
  iueCuenta:     string;
  rcivaPercent:  number;
  rcivaCuenta:   string;
  exentoPercent: number;
  ctaExento:     string;
  tasa:          number;
  ice:           number;
}

export type UpdateDocumentoPayload = Partial<CreateDocumentoPayload>;

// Tipos de documento SAP
export const TIPO_DOC_SAP_OPTIONS = [
  { value: 0,  label: 'SIN ASIGNAR' },
  { value: 1,  label: '1 - COMPRA' },
  { value: 2,  label: '2 - Boleto BSP' },
  { value: 3,  label: '3 - Importación' },
  { value: 4,  label: '4 - Recibo de alquiler' },
  { value: 5,  label: '5 - Nota de débito proveedor' },
  { value: 6,  label: '6 - Nota de crédito cliente' },
  { value: 7,  label: '7 - VENTA' },
  { value: 8,  label: '8 - Nota de débito cliente' },
  { value: 9,  label: '9 - Nota de crédito proveedor' },
  { value: 10, label: '10 - SIN ASIGNAR' },
];

// Tipos de cálculo
export const TIPO_CALC_OPTIONS = [
  { value: 'G', label: 'Grossing Up' },
  { value: 'D', label: 'Grossing Down' },
];