﻿export * from './paginator.component';
